create function update_geslo(staro_geslo character varying, novo_geslo character varying) returns void
    language plpgsql
as
$$
    --DECLARE id_f INTEGER;
BEGIN
    UPDATE uporabniki SET geslo=novo_geslo WHERE geslo=staro_geslo;
END;
$$;

alter function update_geslo(varchar, varchar) owner to vyrnewjo;

