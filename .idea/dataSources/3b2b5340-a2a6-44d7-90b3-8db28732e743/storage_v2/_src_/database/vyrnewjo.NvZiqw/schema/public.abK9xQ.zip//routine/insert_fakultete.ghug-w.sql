create function insert_fakultete(ime_f character varying, kljucna_beseda_f character varying, opis_f character varying, kraj_f character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO fakultete (ime, kljucna_beseda, opis, kraj_id) VALUES (ime_f, kljucna_beseda_f, opis_f, (SELECT id FROM kraji WHERE ime=kraj_f));
END;
$$;

alter function insert_fakultete(varchar, varchar, varchar, varchar) owner to vyrnewjo;

