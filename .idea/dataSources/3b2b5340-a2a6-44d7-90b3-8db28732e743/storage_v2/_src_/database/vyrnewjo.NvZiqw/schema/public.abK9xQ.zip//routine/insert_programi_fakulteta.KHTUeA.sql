create function insert_programi_fakulteta(ime_p character varying, opis_p character varying, stopnja_p character varying, fakulteta_p character varying, ime_f character varying, kljucna_f character varying, opis_f text, kraj_f character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO programi (ime, opis, stopnja_id, fakulteta_id) VALUES (ime_p, opis_p, (SELECT id FROM stopnje WHERE naziv=stopnja_p),
                                                                       (SELECT id FROM fakultete WHERE ime=fakulteta_p));
    INSERT INTO fakultete (ime, kljucna_beseda, opis, kraj_id)
                        VALUES (ime_f, kljucna_f, opis_f, (SELECT id FROM kraji WHERE ime=kraj_f));
END;
$$;

alter function insert_programi_fakulteta(varchar, varchar, varchar, varchar, varchar, varchar, text, varchar) owner to vyrnewjo;

