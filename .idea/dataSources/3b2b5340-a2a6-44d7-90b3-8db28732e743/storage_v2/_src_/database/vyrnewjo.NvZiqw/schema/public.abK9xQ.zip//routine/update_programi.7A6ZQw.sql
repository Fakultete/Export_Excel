create function update_programi(id_p integer, ime_p character varying, opis_p character varying, stopnja_p character varying, fakulteta_p character varying) returns void
    language plpgsql
as
$$
    --DECLARE id_f INTEGER;
BEGIN
    UPDATE programi p SET ime=ime_p, opis=opis_p, stopnja_id=(SELECT id FROM stopnje WHERE naziv=stopnja_p),
                          fakulteta_id= (SELECT id FROM fakultete WHERE ime=fakulteta_p) WHERE p.id=id_p;
END;
$$;

alter function update_programi(integer, varchar, varchar, varchar, varchar) owner to vyrnewjo;

