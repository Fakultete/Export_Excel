create function update_fakultete(id_f integer, ime_f character varying, kljucna_beseda_f character varying, opis_f character varying, kraj_f character varying) returns void
    language plpgsql
as
$$
    --DECLARE id_f INTEGER;
BEGIN
    UPDATE fakultete f SET ime=ime_f, kljucna_beseda=kljucna_beseda_f, opis=opis_f, kraj_id= (SELECT k.id FROM kraji k WHERE k.ime=kraj_f) WHERE f.id=id_f;
END;
$$;

alter function update_fakultete(integer, varchar, varchar, varchar, varchar) owner to vyrnewjo;

