create function select_fakultete_combobox()
    returns TABLE(ime character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT f.ime FROM fakultete f ORDER BY f.ime ASC;
END;
$$;

alter function select_fakultete_combobox() owner to vyrnewjo;

