create function arhiv_fakultete() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO arhiv_fakultet(id, ime, kljucna_beseda, opis, kraj_id, datum_spremembe)
    VALUES (old.id, old.ime, old.kljucna_beseda, old.opis, old.kraj_id, NOW());
    RETURN NULL;
END;
$$;

alter function arhiv_fakultete() owner to vyrnewjo;

