create function st_fakultete_programi() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE fakultete f SET st_programov=(SELECT COUNT(*) FROM programi WHERE fakulteta_id=f.id);
    RETURN NULL;
END;
$$;

alter function st_fakultete_programi() owner to vyrnewjo;

