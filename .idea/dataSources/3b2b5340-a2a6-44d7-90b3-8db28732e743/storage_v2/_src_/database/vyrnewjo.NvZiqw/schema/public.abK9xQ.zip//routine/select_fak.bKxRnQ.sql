create function select_fak()
    returns TABLE(id integer, ime character varying, kljucno character varying, opis text, kraj character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT f.id,
           f.ime,
           f.kljucna_beseda,
           f.opis,
           k.ime FROM fakultete f INNER JOIN kraji k ON k.id=f.kraj_id ORDER BY f.id;

END;
$$;

alter function select_fak() owner to vyrnewjo;

