create function insert_uporabniki(username_u character varying, pass_u character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO uporabniki (username, geslo) VALUES (username_u, pass_u);
END;
$$;

alter function insert_uporabniki(varchar, varchar) owner to vyrnewjo;

