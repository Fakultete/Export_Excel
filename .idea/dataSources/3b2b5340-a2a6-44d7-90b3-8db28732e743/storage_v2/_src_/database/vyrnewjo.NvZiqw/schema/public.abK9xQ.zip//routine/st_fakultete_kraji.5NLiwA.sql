create function st_fakultete_kraji() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE kraji k SET st_fakultet=(SELECT COUNT(*) FROM fakultete WHERE kraj_id=k.id);
    RETURN NULL;
END;
$$;

alter function st_fakultete_kraji() owner to vyrnewjo;

