create function select_user(username_u character varying, pass_u character varying) returns void
    language plpgsql
as
$$
    DECLARE k VARCHAR;
BEGIN
    SELECT INTO k username, geslo FROM uporabniki WHERE username=username_u AND geslo=pass_u;
END;
$$;

alter function select_user(varchar, varchar) owner to vyrnewjo;

