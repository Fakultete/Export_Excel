create function select_kraji_combobox()
    returns TABLE(ime character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT k.ime FROM kraji k LEFT OUTER JOIN fakultete f on k.id = f.kraj_id ORDER BY k.ime ASC;
END;
$$;

alter function select_kraji_combobox() owner to vyrnewjo;

