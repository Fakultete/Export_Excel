create function izpis_iz_baze() returns void
    language plpgsql
as
$$ BEGIN SELECT f.ime, f.kljucna_beseda, split_part(k.ime, ' ', 1) FROM fakultete f INNER JOIN kraji k ON k.id=f.kraj_id; END; 
$$;

alter function izpis_iz_baze() owner to vyrnewjo;

