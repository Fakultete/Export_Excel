create function delete_programi(id_p integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM programi WHERE id=id_p;
END;
$$;

alter function delete_programi(integer) owner to vyrnewjo;

