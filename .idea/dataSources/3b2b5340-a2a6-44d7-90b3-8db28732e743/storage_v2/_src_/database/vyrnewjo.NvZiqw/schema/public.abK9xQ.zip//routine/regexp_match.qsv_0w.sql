create function regexp_match(citext, citext) returns text[]
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter function regexp_match(citext, citext) owner to postgres;

