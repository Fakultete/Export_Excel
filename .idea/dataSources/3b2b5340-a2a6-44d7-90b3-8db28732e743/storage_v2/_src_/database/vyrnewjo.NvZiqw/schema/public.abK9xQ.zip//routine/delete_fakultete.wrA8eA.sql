create function delete_fakultete(id_f integer) returns void
    language plpgsql
as
$$
BEGIN
   DELETE FROM fakultete WHERE id=id_f;
END;
$$;

alter function delete_fakultete(integer) owner to vyrnewjo;

