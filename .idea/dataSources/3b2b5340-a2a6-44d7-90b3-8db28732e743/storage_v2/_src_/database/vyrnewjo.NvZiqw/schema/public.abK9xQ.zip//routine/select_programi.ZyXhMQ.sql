create function select_programi()
    returns TABLE(id integer, ime character varying, opis text, stopnja character varying, fakulteta character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.id,
               p.ime,
               p.opis,
               s.naziv,
               f.ime FROM programi p INNER JOIN stopnje s ON s.id=p.stopnja_id INNER JOIN fakultete f ON f.id=p.fakulteta_id ORDER BY p.id;

END;
$$;

alter function select_programi() owner to vyrnewjo;

