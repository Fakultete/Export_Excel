create function insert_programi(ime_p character varying, opis_p character varying, stopnja_p character varying, fakulteta_p character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO programi (ime, opis, stopnja_id, fakulteta_id) VALUES (ime_p, opis_p, (SELECT id FROM stopnje WHERE naziv=stopnja_p),
                                                                       (SELECT id FROM fakultete WHERE ime=fakulteta_p));
END;
$$;

alter function insert_programi(varchar, varchar, varchar, varchar) owner to vyrnewjo;

