create function select_stopnja()
    returns TABLE(ime character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT DISTINCT s.naziv FROM stopnje s LEFT OUTER JOIN programi p ON s.id=p.stopnja_id;
END;
$$;

alter function select_stopnja() owner to vyrnewjo;

